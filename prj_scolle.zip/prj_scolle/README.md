# 🏫 Group Scolaire Dashboard — Teacher Login (Backend)

Dashboard web pour gérer **Students** et **Projects** avec:
- SPA (sections)
- KPIs
- Filtrage + Tri
- API publique (RandomUser)
- Backend Node.js + Express (db.json)
- ✅ Login Prof via Backend: `POST /api/teachers/login`
- Les profs (name/code) sont stockés dans `backend/db.json`

## ✅ Comptes Prof (demo)
- Prof Ahmed / 1234
- Prof Sara / 5678

👉 Vous pouvez ajouter d'autres profs dans `backend/db.json` → champ `teachers`.

## ▶️ Lancement (Sans Docker)
### Backend
```bash
cd backend
npm install
npm start
```
API: http://localhost:3000

### Frontend
Ouvrir `frontend/index.html` dans le navigateur.

## 🐳 Docker
```bash
docker-compose up --build
```
Frontend: http://localhost:5173
Backend:  http://localhost:3000
