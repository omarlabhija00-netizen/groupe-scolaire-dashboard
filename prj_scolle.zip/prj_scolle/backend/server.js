const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");//
const { v4: uuidv4 } = require("uuid");

const app = express();
app.use(cors());
app.use(express.json());

const DB_PATH = path.join(__dirname, "db.json");
const PORT = 3000;

// ---------- Helpers ----------
//ce fonction poure lire la base de donnee 
function readDB() {
  try {
    if (!fs.existsSync(DB_PATH)) {
      const base = { students: [], projects: [], teachers: [] };
      fs.writeFileSync(DB_PATH, JSON.stringify(base, null, 2));
      return base;
    }
    const raw = fs.readFileSync(DB_PATH, "utf-8");
    return JSON.parse(raw || "{}");
  } catch (err) {
    console.error("[DB READ ERROR]", err);
    return { students: [], projects: [], teachers: [] };
  }
}

// Atomic write: write to temp file then rename
//had fonction katkteb f database
function writeDB(data) {
  try {
    const tmp = DB_PATH + ".tmp";
    fs.writeFileSync(tmp, JSON.stringify(data, null, 2), { encoding: "utf-8" });
    fs.renameSync(tmp, DB_PATH);
    return true;
  } catch (err) {
    console.error("[DB WRITE ERROR]", err);
    try { if (fs.existsSync(DB_PATH + ".tmp")) fs.unlinkSync(DB_PATH + ".tmp"); } catch (e) {}
    return false;
  }
}



// ---------- Teachers Login (Backend) ----------
//
app.post("/api/teachers/login", (req, res) => {
  const { name, code } = req.body;
  if (!name || !code) return res.status(400).json({ message: "Champs manquants" });

  const db = readDB();
  const teacher = (db.teachers || []).find(t => t.name === name && t.code === code);
  if (!teacher) return res.status(401).json({ message: "Nom ou Code incorrect ❌" });

  // Simple session token (not JWT) just to confirm login on frontend
  const token = "teacher-" + teacher.id + "-" + Date.now();
  res.json({ token, teacher: { id: teacher.id, name: teacher.name } });
});

// ---------- Students ----------

app.get("/api/students", (req, res) => {
  const db = readDB();
  res.json(db.students);
});
//had fonction katzid student jdida f database
app.post("/api/students", (req, res) => {
  const { name, level, avg } = req.body;
  if (!name || !level || avg === undefined) return res.status(400).json({ message: "Champs manquants" });

  const db = readDB();
  const student = { id: uuidv4(), name, level, avg: Number(avg

  ) };
  db.students.push(student);
  writeDB(db);
  res.json(student);
});

app.delete("/api/students/:id", (req, res) => {
  const { id } = req.params;
  const db = readDB();
  const before = db.students.length;
  db.students = db.students.filter(s => s.id !== id);
  if (db.students.length === before) return res.status(404).json({ message: "Student introuvable" });
  console.log(`[DELETE] student id=${id} — before=${before} after=${db.students.length}`);
  if (!writeDB(db)) {
    console.error(`[DELETE] Failed to persist deletion for student id=${id}`);
    return res.status(500).json({ message: "Échec écriture DB" });
  }
  console.log(`[DELETE] Persisted student id=${id}`);
  return res.json({ message: "Supprimé ✅", students: db.students });
});

// ---------- Projects ----------
app.get("/api/projects", (req, res) => {
  const db = readDB();
  res.json(db.projects);
});

app.post("/api/projects", (req, res) => {
  const { title, owner, grade } = req.body;
  if (!title || !owner || grade === undefined) return res.status(400).json({ message: "Champs manquants" });

  const db = readDB();
  const project = { id: uuidv4(), title, owner, grade: Number(grade) };
  db.projects.push(project);
  writeDB(db);
  res.json(project);
});

app.delete("/api/projects/:id", (req, res) => {
  const { id } = req.params;
  const db = readDB();
  const before = db.projects.length;
  db.projects = db.projects.filter(p => p.id !== id);
  if (db.projects.length === before) return res.status(404).json({ message: "Project introuvable" });
  console.log(`[DELETE] project id=${id} — before=${before} after=${db.projects.length}`);
  if (!writeDB(db)) {
    console.error(`[DELETE] Failed to persist deletion for project id=${id}`);
    return res.status(500).json({ message: "Échec écriture DB" });
  }
  console.log(`[DELETE] Persisted project id=${id}`);
  return res.json({ message: "Supprimé ✅", projects: db.projects });
});

// ---------- Health ----------
app.get("/", (req, res) => res.send("Group Scolaire API (No Login) ✅"));

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));

