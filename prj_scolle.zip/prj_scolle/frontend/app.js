// Group Scolaire Dashboard — Frontend (No Login)
// Backend: http://localhost:3000

const API_BASE = "http://localhost:3000";


// ---------- Teacher Login (Backend) ----------
//had kadir l login dyal teacher
function handleTeacherLogin() {
  const name = document.getElementById("profName").value.trim();
  const code = document.getElementById("profCode").value.trim();
  const error = document.getElementById("loginError");
  error.textContent = "";
//had fetch katb3t l data dyal login l backend
  fetch(`${API_BASE}/api/teachers/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, code })
  })
    .then(res => res.json().then(data => ({ ok: res.ok, data })))
    .then(({ ok, data }) => {
      if (!ok) {
        error.textContent = data.message || "Erreur login";
        return;
      }
      // Save session
      localStorage.setItem("teacherToken", data.token);
      localStorage.setItem("teacherName", data.teacher.name);
      checkTeacherSession();
    })
    .catch(() => {
      error.textContent = "Erreur réseau";
    });
}
//had l fonction katmchi mli teacher kaydkhal login

function logoutTeacher() {
  localStorage.removeItem("teacherToken");
  localStorage.removeItem("teacherName");
  alert("Logout ✅");
  checkTeacherSession();
}
//had l fonction katchecki wach teacher mdakhl wla la
function checkTeacherSession() {
  const teacher = localStorage.getItem("teacherToken");
  const teacherName = localStorage.getItem("teacherName");
  const header = document.getElementById("header");
  const userBox = document.getElementById("userBox");

  if (teacher) {
    header.classList.remove("hidden");
    if (userBox) userBox.textContent = teacherName || "Prof";
    showSection("dashboard");
  } else {
    header.classList.add("hidden");
    if (userBox) userBox.textContent = "";
    showSection("login");
  }
}


// ---------- SPA ----------
function showSection(id) {
  document.querySelectorAll("section").forEach(sec => sec.classList.add("hidden"));
  const target = document.getElementById(id);
  if (target) target.classList.remove("hidden");
}

// ---------- Fetch helpers (No JWT) ----------
async function apiGET(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error("GET error");
  return res.json();
}
async function apiPOST(url, body) {
  const res = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || "POST error");
  return data;
}
async function apiDEL(url) {
  const res = await fetch(url, { method: "DELETE" });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || "DELETE error");
  return data;
}

// ---------- Students ----------
let students = [];
function displayStudents(arr = students) {
  const ul = document.getElementById("studentsList");
  ul.innerHTML = "";

  arr.forEach(s => {
    const li = document.createElement("li");
    li.innerHTML = `
      <div>
        <b>${s.name}</b> <span class="pill">${s.level}</span><br/>
        <small>Moyenne: ${s.avg}</small>
      </div>
      <button class="btn danger" onclick="deleteStudent('${s.id}')">Delete</button>
    `;
    ul.appendChild(li);
  });
}
async function loadStudents() {
  students = await apiGET(`${API_BASE}/api/students`);
  displayStudents(students);
}
async function addStudent() {
  const name = document.getElementById("stName").value.trim();
  const level = document.getElementById("stLevel").value.trim();
  const avg = Number(document.getElementById("stAvg").value);

  if (!name || !level || isNaN(avg)) return alert("Champs invalides");

  await apiPOST(`${API_BASE}/api/students`, { name, level, avg });
  document.getElementById("stName").value = "";
  document.getElementById("stLevel").value = "";
  document.getElementById("stAvg").value = "";
  await refreshAll();
}
async function deleteStudent(id) {
  if (!confirm("Delete student?")) return;
  await apiDEL(`${API_BASE}/api/students/${id}`);
  await refreshAll();
}
//filtre w sort dyal students
function filterStudents() {
  const q = document.getElementById("studentSearch").value.toLowerCase().trim();
  displayStudents(students.filter(s => s.name.toLowerCase().includes(q)));
}
function sortStudentsAZ() {
  displayStudents([...students].sort((a,b)=>a.name.localeCompare(b.name)));
}

// ---------- Projects ----------
let projects = [];
function displayProjects(arr = projects) {
  const ul = document.getElementById("projectsList");
  ul.innerHTML = "";

  arr.forEach(p => {
    const li = document.createElement("li");
    li.innerHTML = `
      <div>
        <b>${p.title}</b><br/>
        <small>Owner: ${p.owner} — Note: ${p.grade}</small>
      </div>
      <button class="btn danger" onclick="deleteProject('${p.id}')">Delete</button>
    `;
    ul.appendChild(li);
  });
}
async function loadProjects() {
  projects = await apiGET(`${API_BASE}/api/projects`);
  displayProjects(projects);
}
async function addProject() {
  const title = document.getElementById("prTitle").value.trim();
  const owner = document.getElementById("prOwner").value.trim();
  const grade = Number(document.getElementById("prGrade").value);

  if (!title || !owner || isNaN(grade)) return alert("Champs invalides");

  await apiPOST(`${API_BASE}/api/projects`, { title, owner, grade });
  document.getElementById("prTitle").value = "";
  document.getElementById("prOwner").value = "";
  document.getElementById("prGrade").value = "";
  await refreshAll();
}
async function deleteProject(id) {
  if (!confirm("Delete project?")) return;
  await apiDEL(`${API_BASE}/api/projects/${id}`);
  await refreshAll();
}
function filterProjects() {
  const q = document.getElementById("projectSearch").value.toLowerCase().trim();
  displayProjects(projects.filter(p => p.title.toLowerCase().includes(q)));
}
function sortProjectsAZ() {
  displayProjects([...projects].sort((a,b)=>a.title.localeCompare(b.title)));
}

// ---------- KPIs ----------
function updateKPIs() {
  document.getElementById("kpiStudents").textContent = students.length;
  document.getElementById("kpiProjects").textContent = projects.length;

  const allGrades = [
    ...students.map(s => Number(s.avg)),
    ...projects.map(p => Number(p.grade))
  ].filter(x => !isNaN(x));

  const avg = allGrades.length ? (allGrades.reduce((a,b)=>a+b,0)/allGrades.length).toFixed(2) : "0";
  document.getElementById("kpiAvg").textContent = avg;
}

// ---------- Public API (RandomUser) ----------
async function loadAPIData() {
  showSection("api");
  const loader = document.getElementById("loader");
  const result = document.getElementById("apiResult");
  loader.classList.remove("hidden");
  result.innerHTML = "";

  try {
    const res = await fetch("https://randomuser.me/api/");
    const data = await res.json();
    const u = data.results[0];

    result.innerHTML = `
      <h3>Suggestion: ${u.name.first} ${u.name.last}</h3>
      <img src="${u.picture.large}" width="160" style="border-radius:16px"/>
      <p><b>Email:</b> ${u.email}</p>
      <p><b>Pays:</b> ${u.location.country}</p>
    `;
  } catch (e) {
    result.textContent = "Erreur API.";
  } finally {
    loader.classList.add("hidden");
  }
}

// ---------- Refresh ----------
async function refreshAll() {
  await loadStudents();
  await loadProjects();
  updateKPIs();
}

// ---------- Init ----------
document.addEventListener("DOMContentLoaded", async () => {
  checkTeacherSession();

  document.getElementById("studentSearch").addEventListener("input", filterStudents);
  document.getElementById("projectSearch").addEventListener("input", filterProjects);

  document.getElementById("sortStudentsBtn").addEventListener("click", sortStudentsAZ);
  document.getElementById("sortProjectsBtn").addEventListener("click", sortProjectsAZ);

  document.getElementById("addStudentBtn").addEventListener("click", addStudent);
  document.getElementById("addProjectBtn").addEventListener("click", addProject);

  document.getElementById("loadApiBtn").addEventListener("click", loadAPIData);

  if (localStorage.getItem("teacherToken")) {
    await refreshAll();
  }
});
